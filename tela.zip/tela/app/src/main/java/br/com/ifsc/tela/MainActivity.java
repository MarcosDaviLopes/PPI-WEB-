package br.com.ifsc.tela;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private int clickCount = 0;
    private TextView textViewCenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewCenter = findViewById(R.id.textViewCenter);
    }

    public void contaClicks(View view) {
        clickCount++;
        textViewCenter.setText("Hello - Clicks: " + clickCount);
    }
}
