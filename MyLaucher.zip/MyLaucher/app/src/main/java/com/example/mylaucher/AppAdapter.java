package com.example.mylaucher;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class AppAdapter extends ArrayAdapter<ApplicationInfo> {

    Context context;
    int resoucer;
    List<ApplicationInfo> listApss;

    public AppAdapter(Context context, int resoucer, List listApss) {
        super(context,resoucer,listApss);
        this.context=context;
        this.resoucer=resoucer;
        this.listApss=listApss;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = LayoutInflater.from(this.context);
        convertView = layoutInflater.inflate(R.layout.item_lista, parent, false);

        ImageView imageView = convertView.findViewById(R.id.app_icon);
        TextView textView = convertView.findViewById(R.id.app_name);

        ApplicationInfo appInfo = this.listApss.get(position);

        textView.setText(appInfo.loadLabel(this.context.getPackageManager()));
        imageView.setImageDrawable(appInfo.loadIcon(this.context.getPackageManager()));

        return convertView;
    }
}

