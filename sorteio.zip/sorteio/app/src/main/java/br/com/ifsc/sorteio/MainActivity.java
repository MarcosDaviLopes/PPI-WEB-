package br.com.ifsc.sorteio;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private TextView textViewResult;
    private EditText editTextLowerLimit;
    private EditText editTextUpperLimit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewResult = findViewById(R.id.textViewResult);
        editTextLowerLimit = findViewById(R.id.editTextLowerLimit);
        editTextUpperLimit = findViewById(R.id.editTextUpperLimit);
    }

    public void sortearNumero(View view) {
        String lowerLimitText = editTextLowerLimit.getText().toString();
        String upperLimitText = editTextUpperLimit.getText().toString();

        if (lowerLimitText.isEmpty() || upperLimitText.isEmpty()) {
            textViewResult.setText("Informe os limites inferiores e superiores.");
            return;
        }

        int lowerLimit = Integer.parseInt(lowerLimitText);
        int upperLimit = Integer.parseInt(upperLimitText);

        if (lowerLimit >= upperLimit) {
            textViewResult.setText("O limite inferior deve ser menor que o limite superior.");
            return;
        }

        Random random = new Random();
        int randomNumber = random.nextInt(upperLimit - lowerLimit + 1) + lowerLimit;
        textViewResult.setText("Número sorteado: " + randomNumber);
    }
}
